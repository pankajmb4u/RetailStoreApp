package com.cdk.retailstore.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdk.retailstore.dao.ProductDAO;
import com.cdk.retailstore.dao.UserDAO;
import com.cdk.retailstore.dao.DiscountDAO;
import com.cdk.retailstore.entity.Product;
import com.cdk.retailstore.entity.AppUser;
import com.cdk.retailstore.entity.Discount;
import com.cdk.retailstore.model.RetailProduct;
import com.cdk.retailstore.model.DiscountPercent;

@Service
public class RetailStoreService {
	
	@Autowired
	private ProductDAO productDao;
	
	@Autowired
	private DiscountDAO discountDao;
	
	@Autowired
	private UserDAO userDao;
		
	DiscountCalculator discCalculator = new DiscountCalculator();
	
	public RetailProduct calculateCost(String productId, String userCategory) {
		RetailProduct retailProd = new RetailProduct();

		Product product = productDao.findProductById(productId);	
		
		retailProd.setProduct(product.getProductName());
		retailProd.setProductCost(product.getProductCost());
		double totalCost = product.getProductCost();
		if(userCategory.equalsIgnoreCase("Regular")){
			totalCost = discCalculator.calculateRegularDiscount(totalCost);
		}else if(userCategory.equalsIgnoreCase("Premium")) {
			totalCost = discCalculator.calculatePremiumDiscount(totalCost);
		}
		retailProd.setTotalCost(totalCost);		
		return retailProd;
	}

	
	
	public List<RetailProduct> getAllProducts() {
		List<RetailProduct> retailProducts = new ArrayList<>();

		List<Product> products = productDao.findAllProducts();
		for(Product product: products) {
			double discount = discountDao.findDiscountByCategory(userDao.findUser("userId").getUserCategory()).getDiscount();
			RetailProduct retailPrd = new RetailProduct();
			retailPrd.setProduct(product.getProductName());
			retailPrd.setProductCost(product.getProductCost());
			double totalCost = product.getProductCost();
			retailPrd.setTotalCost(totalCost);
			retailProducts.add(retailPrd);
		}
		return retailProducts;
	}

	public DiscountPercent getDiscount(String category) {
		Discount discount = discountDao.findDiscountByCategory(category);
		DiscountPercent discountPercent = new DiscountPercent();
		discountPercent.setDiscountPercentage(discount.getDiscount());
		return discountPercent;
	}

	public AppUser getUser(String userId) {
		AppUser user = userDao.findUser(userId);
		return user;
	}
}
