package com.cdk.retailstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cdk.retailstore.model.RetailProduct;
import com.cdk.retailstore.model.DiscountPercent;
import com.cdk.retailstore.service.RetailStoreService;

@RestController
public class RetailStoreController {

	@Autowired
	private RetailStoreService retailStoreService;
	
	@GetMapping("/products/cost/{productId}/{category}")
	public RetailProduct getProductCost(@PathVariable String productId, @PathVariable String category) {
		return retailStoreService.calculateCost(productId, category);
	}
	
	@GetMapping("/products/getAllProducts")
	public List<RetailProduct> getAllProducts(@PathVariable String productId) {
		return retailStoreService.getAllProducts();
	}
	
	@GetMapping("/discount/{category}")
	public DiscountPercent getDiscount(@PathVariable String category) {
		return retailStoreService.getDiscount(category);
	}
}
