package com.cdk.retailstore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Discount")
public class Discount {

	@GeneratedValue
	@Id
	String discountId;
	
    @Column(name = "Category")
	String category;

    @Column(name = "Discount")
    double discount;

	public String getDiscountId() {
		return discountId;
	}

	public void setDiscountId(String discountId) {
		this.discountId = discountId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	@Override
	public String toString() {
		return "Discount [discountId=" + discountId + ", category=" + category + ", discount=" + discount + "]";
	}

	
}
