package com.cdk.retailstore.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.cdk.retailstore.entity.AppUser;

public class UserDAO {
	 @Autowired
	    private SessionFactory sessionFactory;
	 
	    public AppUser findUser(String userId) {
	        Session session = this.sessionFactory.getCurrentSession();
	        return session.find(AppUser.class, userId);
	    }
	   
}
