package com.cdk.retailstore.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cdk.retailstore.entity.Product;

@Transactional
@Repository
public class ProductDAO {
 
    @Autowired
    private SessionFactory sessionFactory;
 
    public Product findProductById(String productId) {
        Session session = this.sessionFactory.getCurrentSession();
        return session.find(Product.class, productId);
    }
 
    public List<Product> findAllProducts() {
        Session session = this.sessionFactory.getCurrentSession();
        @SuppressWarnings("unchecked")
		List<Product> products = (List<Product>) session.createQuery("from Product").list();
        return products;
    }
}
