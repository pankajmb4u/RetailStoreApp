package com.cdk.retailstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdk.retailstore.entity.Discount;

public interface DiscountRepository extends JpaRepository<Discount, String>{

	Discount findTaxByCategory(String category);
}
