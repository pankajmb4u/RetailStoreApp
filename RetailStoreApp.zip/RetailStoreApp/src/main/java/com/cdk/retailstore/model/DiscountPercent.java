package com.cdk.retailstore.model;

import javax.persistence.GeneratedValue;

import org.springframework.data.annotation.Id;

public class DiscountPercent {

	@GeneratedValue
	@Id
	String discountId;
	
	double discountPercentage;
	String category;
	public String getDiscountId() {
		return discountId;
	}
	public void setDiscountId(String discountId) {
		this.discountId = discountId;
	}
	public double getDiscountPercentage() {
		return discountPercentage;
	}
	public void setDiscountPercentage(double discountPercentage) {
		this.discountPercentage = discountPercentage;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "DiscountPercent [discountId=" + discountId + ", discountPercentage=" + discountPercentage
				+ ", category=" + category + "]";
	}

	
}
