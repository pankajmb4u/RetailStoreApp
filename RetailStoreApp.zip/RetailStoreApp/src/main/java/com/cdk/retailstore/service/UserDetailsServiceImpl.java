package com.cdk.retailstore.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.cdk.retailstore.dao.UserDAO;
import com.cdk.retailstore.entity.AppUser;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
 
    @Autowired
    private UserDAO userDao;
 
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AppUser user = userDao.findUser(username);
        System.out.println("user= " + user);
 
        if (user == null) {
            throw new UsernameNotFoundException("User " //
                    + username + " was not found in the database");
        }
 
        // User category - Regular or Premium
        String category = user.getUserCategory();
 
        List<GrantedAuthority> grantList = new ArrayList<GrantedAuthority>();
 
        // Regular or Premium
        GrantedAuthority authority = new SimpleGrantedAuthority(category);
 
        grantList.add(authority);
 
        boolean enabled = user.isActive();
        boolean accountNonExpired = true;
        boolean credentialsNonExpired = true;
        boolean accountNonLocked = true;
 
        UserDetails userDetails = (UserDetails) new User(user.getUserName(), //
                user.getEncrytedPassword(), enabled, accountNonExpired, //
                credentialsNonExpired, accountNonLocked, grantList);
 
        return userDetails;
    }
 
}
