package com.cdk.retailstore.model;

public class RetailProduct {
	private String product;
	private double productCost;
	private double discountedCost;
	
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	
	public double getProductCost() {
		return productCost;
	}
	public void setProductCost(double productCost) {
		this.productCost = productCost;
	}
	public double getTotalCost() {
		return discountedCost;
	}
	public void setTotalCost(double totalCost) {
		this.discountedCost = totalCost;
	}
	@Override
	public String toString() {
		return "RetailProduct [product=" + product + ", productCost=" + productCost + ", discountedCost=" + discountedCost + "]";
	}
	
		
}
