package com.cdk.retailstore.repository;

import org.springframework.stereotype.Repository;

import com.cdk.retailstore.entity.AppUser;

@Repository
public interface UserRepository {
	AppUser findByProductId(String userId);
}
