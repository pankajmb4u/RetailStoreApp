package com.cdk.retailstore.service;

import org.springframework.stereotype.Service;

@Service
public class DiscountCalculator {
	
	public double calculateRegularDiscount(double cost) {
		double orignal_cost = cost;
		int discountedCost = 0;
		
		if(cost == 0) return discountedCost;
		
		if(cost >0 && cost < 5000) {
			return discountedCost;
		}
		if(cost > 5000 && cost < 10000) {
			int k = (int)(cost / 100)*10;			
			discountedCost = (int) (orignal_cost -k);
		}
		if(cost > 10000) {
			cost = cost - 10000;
			int k = (int)(cost / 100)*20;	
			
			discountedCost = (int) (orignal_cost -k) - 500;
		}
		
		return discountedCost;
	}
	
	public double calculatePremiumDiscount(double cost) {
		double orignal_cost = cost;
		int discountedCost = 0;
		if(cost == 0) return discountedCost;
		
		if(cost >0 && cost < 4000) {
			int k = (int)(cost / 100)*10;			
			discountedCost = (int) (orignal_cost -k);
		}
		if(cost > 4000 && cost < 8000) {
			cost = cost - 400;
			int k = (int)(cost / 100)*15;			
			discountedCost = (int) (orignal_cost -k) - 400;
		}
		if(cost > 8000 && cost < 12000) {
			int i = (4000/100) * 10;
			int j = (4000/100) * 15;
			cost = cost - (i+j);
			int k = (int)(cost / 100)*20;			
			discountedCost = (int) (orignal_cost -k) - (i+j);
		}
		if(cost > 12000) {
			int i = (4000/100) * 10;
			int j = (4000/100) * 15;
			int k = (4000/100) * 20;
			cost = cost - (i+j+k);
			int z = (int)(cost / 100)*20;			
			discountedCost = (int) (orignal_cost -z) - (i+j+k);
		}
		return discountedCost;
	}

}
