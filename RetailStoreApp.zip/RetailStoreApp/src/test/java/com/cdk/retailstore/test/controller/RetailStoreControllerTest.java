package com.cdk.retailstore.test.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.cdk.retailstore.controller.RetailStoreController;
import com.cdk.retailstore.model.RetailProduct;
import com.cdk.retailstore.service.RetailStoreService;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class RetailStoreControllerTest {

	@InjectMocks
	private RetailStoreController retailStoreController;
	
	@Mock
	private RetailStoreService retailStoreService;
	
	@Test
	public void testProductCost() {
		RetailProduct prodResponse = new RetailProduct();
		prodResponse.setProduct("Laptop");
		prodResponse.setProductCost(4000.00);
		prodResponse.setTotalCost(3500);
		Mockito.when(retailStoreService.calculateCost(Mockito.anyString(), Mockito.anyString())).thenReturn(prodResponse);
		
		prodResponse = retailStoreController.getProductCost("1234", "Regular");
		
		assertNotNull(prodResponse);
		assertTrue(prodResponse.getTotalCost() != 0.0);
		
		
	}
	
		
}
