package com.cdk.retailstore.test.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.cdk.retailstore.dao.ProductDAO;
import com.cdk.retailstore.dao.DiscountDAO;
import com.cdk.retailstore.entity.Product;
import com.cdk.retailstore.entity.Discount;
import com.cdk.retailstore.model.RetailProduct;
import com.cdk.retailstore.service.RetailStoreService;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class RetailStoreServiceTest {

		
	@InjectMocks
	private RetailStoreService retailStoreService;
	
	@Mock
	private ProductDAO productDao;
	
	@Mock
	private DiscountDAO discountDao;
	
	@Test
	public void testProductCost() {
		Product product = new Product();
		product.setProductId("100");
		product.setProductName("Camera");
		product.setProductCost(15000);
		
		Discount discount = new Discount();
		discount.setCategory("Regular");
		discount.setDiscount(20);
		
		Mockito.when(productDao.findProductById(Mockito.anyString())).thenReturn(product);
		//Mockito.when(discountDao.findDiscountByCategory(Mockito.anyString())).thenReturn(discount);
		RetailProduct prodResponse = retailStoreService.calculateCost("1234", "Regular");
		
		assertNotNull(prodResponse);
		assertTrue(prodResponse.getTotalCost() == 13500);
		
		
	}
	
		
}
